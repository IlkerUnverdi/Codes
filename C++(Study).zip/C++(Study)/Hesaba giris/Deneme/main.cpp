//
//  main.cpp
//  Deneme
//
//  Created by İlker Ünverdi on 10/12/23.
//

#include <iostream>

using namespace std;

int main(){
    string username, password, yes, no, singin;
    cout << "Enter a username to sing up" << endl;
    cin >> username;
    cout << "Welcome " << username << endl << "Now please enter a password to create an account" << endl;
    cin >> password;
    cout << "Do you want to sing in now?" << endl;
    cin >> singin;
    while (true) {
        if (singin == "yes") {
            cout << "Enter your username to log in" << endl;
            break;
        }
        else if (singin == "no")
        {
            cout << "Okey then, see you later!" << endl;
        }
        else
        {
            cout << "I am sorry, I could not catch you. Could you repeat it for me? Only 'yes' or 'no'" << endl;
        }
    }
    return 0;
    
}
