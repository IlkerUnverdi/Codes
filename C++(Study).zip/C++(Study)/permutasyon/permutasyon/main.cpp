//
//  main.cpp
//  permutasyon
//
//  Created by İlker Ünverdi on 10/24/23.
//

#include <iostream>

using namespace std;
int main(){
    char a = 'm';
    char b = 'u';
    char c = 'r';
    char d = 'o';
    for (int i = 1; i <= 4; i++) {
        cout << a << endl;
    }
}
