//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/20/23.
//

#include <iostream>

using namespace std;

int main(){
    
    int arr[5];
    arr[0] = 20;
    arr[1] = 33;
    arr[2] = 42;
    arr[3] = 39;
    arr[4] = 55;
    
    for (int i = 0; i<5; i++) {
        cout << arr[i] << endl;
    }
    
}
