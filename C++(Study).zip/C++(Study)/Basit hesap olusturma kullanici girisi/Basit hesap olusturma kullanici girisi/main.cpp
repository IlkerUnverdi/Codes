//
//  main.cpp
//  Basit hesap olusturma kullanici girisi
//
//  Created by İlker Ünverdi on 10/12/23.
//

#include <iostream>

using namespace std;

int main(){
    string username, user;
    string signin;
    int password, pass;
    cout << "Enter a username to sing up" << endl;
    cin >> username;
    cout << "Welcome " << username << endl << "Now please enter a password to create an account" << endl;
    cin >> password;
    while (true) {
        cout << "Do you want to sing in now?" << endl;
        cin >> signin;
        if (signin == "yes") {
            cout << "Enter your username to log in" << endl;
            break;
        }
        else if (signin == "no")
        {
            cout << "Okey then, see you later!" << endl;
            return 0;
        }
        else
        {
            cout << "I am sorry, I could not catch you. Could you re-enter it? Only 'yes' or 'no'" << endl;
        }
    }
    while (true) {
        cout << "Please enter your username" << endl;
        cin >> user;
        if (user == username) {
            cout << "Please enter your password" << endl;
            break;
        }
        else
        {
            cout << "Username is wrong, please enter again!" << endl;
        }
    }
    while (true) {
        cin >> pass;
        if (pass == password) {
            cout << "Welcome" << endl;
            break;
        }
        else
        {
            cout << "Password is wrong, please re-enter it again!" << endl;
        }
        
    }
    return 0;
    
}
