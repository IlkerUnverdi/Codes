//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/31/23.
//

#include <iostream>

using namespace std;

int main(){
    int x;
    cout << "Array kac tam sayi icersin: ";
    cin >> x;
    int *p = new int[x];
    for (int i = 0; i < x; i++) {
        cin >> p[i];
    }
    for (int i = 0; i < x; i++) {
        cout << p[i] << " ";
    }
    delete [] p;
    return 0;
}
