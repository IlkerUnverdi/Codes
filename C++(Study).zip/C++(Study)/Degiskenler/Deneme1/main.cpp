//
//  main.cpp
//  Deneme1
//
//  Created by İlker Ünverdi on 10/8/23.
//


#include <iostream>

using namespace std;
int main() {
    
    string name = "Ilker Unverdi";
    int age = 19;
    char average = 'A' ;
    double averageasnumber = 3.75;
    bool absent = true;
     
    cout << "Merhaba" << endl << "Ogrenci adi - Soyadi: " << name << endl;
    cout << "Ogrenci Yasi: " << age << endl;
    cout << "Not Ortalamasi: " << average << endl;
    cout << "Sayisal Not ortalamasi: " << averageasnumber << endl;
    cout << "Sinava Girdi mi? " << absent << endl;
    cout << "Yas+Ortalama Toplami: " << age*averageasnumber << endl;
    
    return 0;
}
