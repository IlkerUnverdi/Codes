//
//  main.cpp
//  STL
//
//  Created by İlker Ünverdi on 12/6/23.
//

#include <iostream>
#include <list>

using namespace std;

void printlist(list<int> l){
    list<int>::iterator itr;
    for (itr = l.begin(); itr != l.end(); itr++) {
        cout << *itr << endl;
    }
}

int main(){
    list<int> lst;  // 5 8
    lst.push_back(5);
    lst.push_back(8);
    lst.push_front(10);
    
    printlist(lst);
    
    lst.pop_back();
    
    cout << endl;
    printlist(lst);
    
    list<int>::iterator it;
    it = lst.begin();
    it++;
    lst.insert(it, 2, 9);
    
    printlist(lst);
    
    
}

