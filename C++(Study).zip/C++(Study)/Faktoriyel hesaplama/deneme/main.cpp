//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/19/23.
//

#include <iostream>
using namespace std;
int main(){
    int faktoriyel;
    int sonuc = 1;
    cout << "Faktoriyelini hesaplamak istediginiz sayiyi girin: ";
    cin >> faktoriyel;
    for (int x = 1; x <= faktoriyel; x++) {
        sonuc *=  x;
    }
    cout << "Sonuc: " << sonuc << endl;
}
