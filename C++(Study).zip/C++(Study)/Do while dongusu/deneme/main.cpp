//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/19/23.
//

#include <iostream>

using namespace std;
int main(){
    string sifre = "1234";
    string girilensifre;
    do {
        cout << "Lutfen sifreyi giriniz: ";
        cin >> girilensifre;
    } while (sifre != girilensifre);
    cout << "Hosgeldiniz" << endl;
    return 0;
}
