//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/31/23.
//

#include <iostream>

using namespace std;

int main(){
    int sayac = 0;
    int birler, onlar, yuzler, binler;
    for (int i = 1000; i<=9999  ; i++) {
        //1234
        birler = i % 10;
        onlar = ((i % 100)-birler)/10 ;
        yuzler = ((i % 1000)-onlar-birler)/100;
        binler = (i -yuzler-onlar-birler)/1000;
        if (birler != onlar && birler != yuzler && birler != binler && onlar != yuzler && onlar != binler && yuzler!= binler) {
            cout << i << endl;
            sayac = sayac +1;
        }
    }
    cout << "1000 ile 9999 arasinda: " << sayac << " adet rakamlari farkli tam sayi vardir." << endl;
    return 0;
}
