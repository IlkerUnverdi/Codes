//
//  Ogrenci.hpp
//  Ogrenci Bilgi Sistemi
//
//  Created by İlker Ünverdi on 12/7/23.
//

#ifndef Ogrenci_hpp
#define Ogrenci_hpp

#include <stdio.h>
#include <iostream>

using namespace std;

class Ogrenci {
private:
    string Isim;
    int OgrenciNo;
    string Sube;
public:
    void obsgoster();
    Ogrenci(string _isim, string _sube, int _ogrencino);
    void setisim(string _isim);
    string getisim();
    void setogrencino(int _ogrencino);
    int getogrencino();
    void setsube(string _sube);
    string getsube();
};

#endif /* Ogrenci_hpp */
