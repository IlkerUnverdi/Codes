//
//  Ogrenci.cpp
//  Ogrenci Bilgi Sistemi
//
//  Created by İlker Ünverdi on 12/7/23.
//

#include "Ogrenci.hpp"

Ogrenci::Ogrenci(string _isim, string _sube, int _ogrencino){
    Isim = _isim;
    Sube = _sube;
    OgrenciNo = _ogrencino;
}

void Ogrenci::obsgoster(){
    cout << "Ad Soyad: " << Isim;
    cout << "  |  Sube: " << Sube;
    cout << "  |  Ogrenci No: " << OgrenciNo << endl;
}

void Ogrenci::setisim(string _isim){
    Isim = _isim;
}

string Ogrenci::getisim(){
    return Isim;
}

void Ogrenci::setsube(string _sube){
     Sube = _sube;
}

string Ogrenci::getsube(){
    return Sube;
}

void Ogrenci::setogrencino(int _ogrencino){
    OgrenciNo = _ogrencino;
}

int Ogrenci::getogrencino(){
    return OgrenciNo;
}
