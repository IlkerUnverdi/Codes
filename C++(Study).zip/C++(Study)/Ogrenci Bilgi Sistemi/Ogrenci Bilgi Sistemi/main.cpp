//
//  main.cpp
//  Ogrenci Bilgi Sistemi
//
//  Created by İlker Ünverdi on 12/7/23.
//

#include <iostream>
#include <list>
#include "Ogrenci.hpp"

using namespace std;

void obsmenu(){
    cout << " * * * * * * * * *\n";
    cout << " *               *\n";
    cout << " *      MENU     *\n";
    cout << " *               *\n";
    cout << " * * * * * * * * *\n";
    cout << "1. Yeni Kayit ekle\n";
    cout << "2. Tum Listeyi Goster\n";
    cout << "3. Ogrenci id ye gore Kayit Sil\n";
    cout << "4. Ogrenci ara\n";
    cout << "5. Cikis\n";
    cout << "Lutfen yapmak istediginiz islemi seciniz:";
}

void ogrenciekle(list<Ogrenci> *liste){
    string isim1, Sube1, ad ,soyad;
    int OgrenciNo1;
    cout << "Bas harfleri buyuk aralarinda bosluk olacak seklinde ogrenci adi soyadi: ";
    cin >> ad >> soyad;
    isim1 = ad + " " + soyad;
    cout << endl;
    cout << "Ogrenci Subesi: ";
    cin >> Sube1;
    cout << endl;
    cout << "Ogrenci No: ";
    cin >> OgrenciNo1;
    cout << endl;
    Ogrenci ogrenci1(isim1, Sube1, OgrenciNo1);
    liste->push_back(ogrenci1);
    ogrenci1.obsgoster();
    cout << "Basariyla eklendi" << endl;
}

void listeyigoster(list<Ogrenci> *liste){
    list<Ogrenci>::iterator it;
    cout << endl << "- - - - Tum Ogrenci listesi - - - -\n";
    for (it = liste->begin(); it != liste->end(); it++) {
        it->obsgoster();
        cout << endl;
    }
}

void ogrencisilme(list<Ogrenci> *liste){
    int id;
    cout << "Silmek istediginiz ogrencinin ogrenci numarasini giriniz: ";
    cin >> id;
    list<Ogrenci>::iterator it;
    for (it = liste->begin(); it != liste->end(); it++){
        if(it->getogrencino() == id) {
            liste->erase(it);
            cout << "Ogrenci basariyla silindi" << endl;
            return;
        }
    }
    cout << "Belirtilen ogrenci numarasi bulunamamistir" << endl;
}

void ogrenciara(list<Ogrenci> *liste){
    string isim1, ad, soyad;
    list<Ogrenci>::iterator it;
    cout << "Aradiginiz ogrencinin ismini giriniz: ";
    cin >> ad >> soyad;
    isim1 = ad + " " + soyad;
    for (it = liste->begin(); it!= liste->end(); it++) {
        if (it->getisim() == isim1) {
            it->obsgoster();
            return;
        }
        else{
            
            cout << "Ogrenci bulunamadi.";
        }
    }
}
 
    
int main(){
    list<Ogrenci> *ogrenciliste = new list<Ogrenci>();
    int secim;
    do {
        obsmenu();
        cin >> secim;
        if (secim == 1) {
            ogrenciekle(ogrenciliste);
        }
        else if (secim == 2){
            listeyigoster(ogrenciliste);
        }
        else if (secim == 3){
            ogrencisilme(ogrenciliste);
        }
        else if (secim == 4){
            ogrenciara(ogrenciliste);
        }
        else{
            cout << "Hatali secim yaptiniz lutfen tekrar deneyiniz" << endl;
        }
    } while (secim != 5);
    cout << "Basariyla Cikis Yaptiniz" << endl;
}
