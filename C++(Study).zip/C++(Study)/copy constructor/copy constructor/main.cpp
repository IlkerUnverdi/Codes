//
//  main.cpp
//  copy constructor
//
//  Created by İlker Ünverdi on 3/22/24.
//

#include <iostream>
#include "Person.hpp"

using namespace std;

int main() {
    Person John("John Doe", 30);
    John.PrintInfo();
    
    Person JohnCopy(John);
    JohnCopy.PrintInfo();
    
    Person Jane("Jane Doe", 28);
    Jane = JohnCopy;
    Jane.PrintInfo();
    
    return 0;
}
