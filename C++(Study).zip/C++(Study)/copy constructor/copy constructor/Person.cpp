//
//  Person.cpp
//  copy constructor
//
//  Created by İlker Ünverdi on 3/22/24.
//

#include "Person.hpp"

Person::Person(const string& name_, int age_)
: name(name_), age(age_){
    
}

Person::Person(const Person& other)
: name(other.name), age(other.age){
    
}

void Person::PrintInfo() const{
    cout << "Name: " << name << ", Age: " << age << endl;
}
