//
//  Person.hpp
//  copy constructor
//
//  Created by İlker Ünverdi on 3/22/24.
//

#ifndef Person_hpp
#define Person_hpp

#include <stdio.h>
#include <iostream>

using namespace std;

class Person {
public:
    Person(const string& name_, int age_);
    
    Person(const Person& other);
    
    Person& operator=(const Person& other) = default;
    
    void PrintInfo() const;
    
private:
    string name;
    int age;
};

#endif /* Person_hpp */
