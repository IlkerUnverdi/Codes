//
//  main.cpp
//  c++ exercise
//
//  Created by İlker Ünverdi on 12/9/23.
//

#include <iostream>

using namespace std;

int main(){
    int n;
    cin >> n;
    int dizi[n];
    cin >> dizi[n];
    for (int i=0; i<n; i++) {
        cin >> dizi[i];
    }
    for (int y = 0; y <n ; y++) {
        cout << dizi[y];
    }
}
