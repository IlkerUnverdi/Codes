//
//  main.cpp
//  Soru Sorma
//
//  Created by İlker Ünverdi on 10/10/23.
//
#include <iostream>

//using namespace std;
int main(){
    std::string answer;
    std::cout << "Do you want to come?" << std::endl;
    std::cin>>answer;
    std::cout<< "You answer was: "<< answer <<std::endl;
    return 0;
}

