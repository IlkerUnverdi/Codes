//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/21/23.
//

#include <iostream>
using namespace std;
int alanHesapla(int x, int y){
    int alan = x * y;
    return alan;
}
void ekranamesajyaz(){
    cout << "Merhaba C++" << endl;
    cout << "Merhaba C++" << endl;
    cout << "Merhaba C++" << endl;
    cout << "Merhaba C++" << endl;
}
void yasGoster(){
    int dogumyili;
    cin >> dogumyili;
    int yas = 2022 - dogumyili;
    cout << yas << endl;
}
int main(){
    cout << alanHesapla(1, 2) << endl;
    ekranamesajyaz();
    yasGoster();
}
