//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/20/23.
//

#include <iostream>
using namespace std;
int main(){
    int faktoriyel;
    cout << "Lutfen bir faktoriyel sayisi giriniz: ";
    cin >> faktoriyel;
    int sonuc = 1;
    for (int i = 1; i <= faktoriyel; i++){
        if (i == 10 || i == 9) {
            break;;
        }
     
        sonuc *= i;
        cout << sonuc << endl;
    }
}
