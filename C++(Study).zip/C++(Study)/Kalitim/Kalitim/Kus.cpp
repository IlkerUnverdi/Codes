//
//  Kus.cpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#include "Kus.hpp"

Kus::Kus(string ad) : Hayvan(ad){
    
}

void Kus::uc(){
    cout << Hayvan::isim << " ucuyor.." << endl;
}
