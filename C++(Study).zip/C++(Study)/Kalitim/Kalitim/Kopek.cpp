//
//  Kopek.cpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#include "Kopek.hpp"

int Kopek::kopeksayisi = 0;
//Constructor
Kopek::Kopek(string ad) : Hayvan(ad){
    kopeksayisi++;
}
//Destructor
Kopek::~Kopek(){
    kopeksayisi--;
}

void Kopek::havla(){
    cout << Kopek::isim << " havliyor..." << endl;
}

int Kopek::karesinihesapla(int x){
    return x*x;
}
