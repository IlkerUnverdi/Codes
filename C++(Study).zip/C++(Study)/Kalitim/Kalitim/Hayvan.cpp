//
//  Hayvan.cpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#include "Hayvan.hpp"

Hayvan::Hayvan(string ad){
    isim = ad;
    hayvansayisi++;
}

Hayvan::~Hayvan(){
    hayvansayisi--;
}

void Hayvan::beslen(){
    cout << isim << " besleniyor.." << endl;
}
void Hayvan::uyu(){
    cout << isim << " uyuyor.." << endl;
}

void Hayvan::setisim(string ad){
    Hayvan::isim = ad;
}

string Hayvan::getisim(){
    return isim;
}

void Hayvan::sescikar(){
    cout << "Hayvan ses cikar fonksiyonu cagirildi" << endl;
}
