//
//  Kus.hpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#ifndef Kus_hpp
#define Kus_hpp

#include <stdio.h>
#include "Hayvan.hpp"

class Kus : public Hayvan {
public:
    Kus(string ad);
    void uc();
};
#endif /* Kus_hpp */
