//
//  Kedi.cpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#include "Kedi.hpp"

Kedi::Kedi(string ad) : Hayvan(ad){
    
}

void Kedi::fareyakala(){
    cout << Hayvan::isim << " Fare Yakaliyor" << endl;
}

void Kedi::sescikar(){
    cout << "Hayvan ses cikar fonksiyonu cagirildi" << endl;
    cout << Hayvan::isim << ": miyav miyav..." << endl;
}
