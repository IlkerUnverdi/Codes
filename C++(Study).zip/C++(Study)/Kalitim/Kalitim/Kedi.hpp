//
//  Kedi.hpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#ifndef Kedi_hpp
#define Kedi_hpp

#include <stdio.h>
#include "Hayvan.hpp"

class Kedi : public Hayvan{
public:
    Kedi(string ad);
    void fareyakala();
    void sescikar();
};

#endif /* Kedi_hpp */
