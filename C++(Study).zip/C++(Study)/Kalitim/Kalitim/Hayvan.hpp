//
//  Hayvan.hpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#ifndef Hayvan_hpp
#define Hayvan_hpp

#include <stdio.h>
#include <iostream>

using namespace std;

class Hayvan {
public:
    void beslen();
    void uyu();
    Hayvan(string ad);
    void setisim(string ad);
    string getisim();
    static int hayvansayisi;
    ~Hayvan();
    virtual void sescikar();
protected:
    string isim;
};
#endif /* Hayvan_hpp */
