//
//  main.cpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#include <iostream>
#include "Hayvan.hpp"
#include "Kedi.hpp"
#include "Kopek.hpp"
#include "Kus.hpp"

using namespace std;

int Hayvan::hayvansayisi = 0;

int main(){

    Kedi Kedi1("Tekir");
    Kopek Kopek1("Karabas");
    Kus Kus1("Mavis");
    
    Kedi1.beslen();
    Kedi1.uyu();
    Kedi1.fareyakala();
    
    Kopek1.beslen();
    Kopek1.uyu();
    Kopek1.havla();
    
    Kus1.beslen();
    Kus1.uyu();
    Kus1.uc();
    
    cout << "Kopek Sayisi: " << Kopek::getkopeksayisi() << endl;
    cout << "Hayvan Sayisi: " << Hayvan::hayvansayisi << endl;
    cout << "5 in karesi: " << Kopek::karesinihesapla(5) << endl;
    
    Kedi1.sescikar();
    
    
    
    return 0;
}


