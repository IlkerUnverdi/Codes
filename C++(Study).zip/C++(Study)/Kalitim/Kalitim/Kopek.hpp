//
//  Kopek.hpp
//  Kalitim
//
//  Created by İlker Ünverdi on 11/28/23.
//

#ifndef Kopek_hpp
#define Kopek_hpp

#include <stdio.h>
#include "Hayvan.hpp"

class Kopek : public Hayvan {
public:
    Kopek(string ad);
    ~Kopek();
    void havla();
    static int getkopeksayisi(){
        return kopeksayisi;
    };
    static int karesinihesapla(int x);
private:
    static int kopeksayisi;// const static te degizmes tanimlarsin header dosyasinda
};


#endif /* Kopek_hpp */
