//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 11/5/23.
//

#include <iostream>

using namespace std;

int main(){
    for (int i = 1; i <= 40; i++) {
        int sayac= 0;
        cout << i << ": ";
        for (int x = 1; x <= i; x++) {
            if (i % x == 0) {
                cout << x << ", ";
                sayac = sayac + 1;
            }
        }
        cout << i << " Sayisinin bolen sayisi: " << sayac << endl;
    }
}
