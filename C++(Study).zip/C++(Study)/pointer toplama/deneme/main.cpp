//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/24/23.
//

#include <iostream>

using namespace std;

void toplama(int *a, int *b){
    int c;
    c = *a + *b;
    cout << c << endl;
}

int main(){
    int a, b;
    int *ptr = &a;
    int *qtr = &b;
    cout << "ilk sayiyi girin: ";
    cin >> a;
    cout << "ikinci sayi: ";
    cin >> b;
    toplama(ptr, qtr);
}
