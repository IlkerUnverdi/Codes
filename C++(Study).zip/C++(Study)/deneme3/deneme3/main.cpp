#include <iostream>

class Time {
private:
    int hours;
    int minutes;

    // Normalizes time so that minutes are less than 60
    void normalize() {
        hours += minutes / 60;
        minutes %= 60;
    }

public:
    // Constructor that initializes time and normalizes it
    Time(int hours, int minutes) : hours(hours), minutes(minutes) {
        normalize();
    }

    // Overload the - operator to subtract two Time objects
    Time operator-(const Time& t) const {
        int totalMinutes1 = this->hours * 60 + this->minutes;
        int totalMinutes2 = t.hours * 60 + t.minutes;
        int diffMinutes = totalMinutes1 - totalMinutes2;

        return Time(diffMinutes / 60, diffMinutes % 60);
    }

    // Function to print the time
    void print() const {
        std::cout << hours << " hours and " << minutes << " minutes" << std::endl;
    }
};

int main() {
    Time t1(5, 150); // Normalization will convert this to 7 hours and 30 minutes
    Time t2(2, 45);

    Time diff = t1 - t2; // Subtract two times

    std::cout << "Time 1: ";
    t1.print();

    std::cout << "Time 2: ";
    t2.print();

    std::cout << "Difference: ";
    diff.print();

    return 0;
}
