//
//  Otomobil.cpp
//  Header
//
//  Created by İlker Ünverdi on 11/6/23.
//

#include "Otomobil.hpp"

Otomobil::Otomobil(string _renk, string _model, int _beygir, int kp){
    cout << "Constructor Cagirildi" << endl;
    renk = _renk;
    beygir = _beygir;
    model = _model;
    pkapisayisi = new int(kp);
    
}

//Otomobil Destructor
Otomobil::~Otomobil(){
    cout << Otomobil::model << " " << "Destructor Cagirildi" << endl;
}
void Otomobil::ruhsatbilgilerigoster(){
    
    cout << "Model: " << Otomobil::model << endl;
    cout << "Renk: " << Otomobil::renk << endl;
    cout << "Beygir: " << Otomobil::beygir << endl;
    cout << "Kapi sayisi: " << *(Otomobil::pkapisayisi)<< endl;
}

void Otomobil::setOtomobilRenk(string _renk){
    renk = _renk;
}

string Otomobil::getOtomobilRenk(){
    cout << endl;
    return renk;
}
void Otomobil::setOtomobilModel(string _model){
    model = _model;
}
string Otomobil::getOtomobilModel(){
    cout << endl;
    return model;
}
void Otomobil::setOtomobilbeygir(int _beygir){
    beygir = _beygir;
}
int Otomobil::getOtomobilbeygir(){
    cout << endl;
    return beygir;
}
void Otomobil::setOtomobilmodelyili(int _modelyili){
    modelyili=_modelyili;
}
int Otomobil::getOtomobilmodelyili(){
    cout << endl;
    return modelyili;
}
