//
//  main.cpp
//  Header
//
//  Created by İlker Ünverdi on 11/6/23.
//

#include <iostream>
#include "Otomobil.hpp"
#include "Motorsiklet.hpp"

using namespace std;

int main(){
    
    Otomobil otomobil1("siyah", "Audi", 85, 4);
    otomobil1.setOtomobilRenk("beyaz");
    otomobil1.setOtomobilModel("BMW");
    otomobil1.setOtomobilbeygir(125);
    otomobil1.ruhsatbilgilerigoster();
    otomobil1.setOtomobilmodelyili(2020);
    cout << endl;
    
    cout << "Audi kapi sayisi: " << *(otomobil1.pkapisayisi)<< endl;
    cout << endl;
    
    Otomobil *p;
    p = new Otomobil("sari", "Mercedes", 123, 4);
    p->setOtomobilRenk("kirmizi");
    p->ruhsatbilgilerigoster();
    cout << endl;
    
    cout << "Mercedes kapi sayisi: " << *(p->pkapisayisi) << endl;
    cout << endl;
    
    Motorsiklet motorsiklet1("beyaz", "yamaha", 200);
    motorsiklet1.motorruhsat();

    cout << otomobil1.getOtomobilRenk();
    cout << otomobil1.getOtomobilModel();
    cout << otomobil1.getOtomobilbeygir();
    cout << otomobil1.getOtomobilmodelyili() << endl;
    delete p; // Pointerlar ile isin bitince sil.
}
