//
//  Motorsiklet.hpp
//  Header
//
//  Created by İlker Ünverdi on 11/6/23.
//

#ifndef Motorsiklet_hpp
#define Motorsiklet_hpp

#include <stdio.h>
#include <iostream>

#endif /* Motorsiklet_hpp */
using namespace std;

class Motorsiklet{
public:
    string renk;
    string model;
    int beygir;
    
    void motorruhsat();
    Motorsiklet(string _renk, string _model, int _beygir);
};

