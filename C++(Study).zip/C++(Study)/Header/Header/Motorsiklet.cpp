//
//  Motorsiklet.cpp
//  Header
//
//  Created by İlker Ünverdi on 11/6/23.
//

#include "Motorsiklet.hpp"

Motorsiklet::Motorsiklet(string _renk, string _model, int _beygir){
    renk = _renk;
    model = _model;
    beygir = _beygir;
}
void Motorsiklet::motorruhsat(){
    
    cout << "Model: " << Motorsiklet::model << endl;
    cout << "Renk: " << Motorsiklet::renk << endl;
    cout << "Beygir: " << Motorsiklet::beygir << endl;
}
