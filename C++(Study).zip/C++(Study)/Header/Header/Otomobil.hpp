//
//  Otomobil.hpp
//  Header
//
//  Created by İlker Ünverdi on 11/6/23.
//

#ifndef Otomobil_hpp
#define Otomobil_hpp

#include <stdio.h>
#include <iostream>

using namespace std;

class Otomobil {
private:
    string renk;
    string model;
    int beygir;
    int modelyili;
public:
    //Constructor
    Otomobil(string _renk, string _model, int _beygir, int kp);
    //Destructor
    ~Otomobil();
    void ruhsatbilgilerigoster();
    
    void setOtomobilRenk(string _renk);
    string getOtomobilRenk();
    void setOtomobilModel(string _model);
    string getOtomobilModel();
    void setOtomobilbeygir(int _beygir);
    int getOtomobilbeygir();
    void setOtomobilmodelyili(int _modelyili);
    int getOtomobilmodelyili();
    
    int *pkapisayisi;
    
    
};

#endif /* Otomobil_hpp */
