#include<iostream>

using namespace std;

int  main(){
    
    char str1 [100],  str2 [100],*p1 = str1 ,*p2 = str2 ;
    cout<<"Enter   string    s1:   " ;
    cin>>str1;cout<<"Enter   string    s2:   " ;
    cin>>str2;
    while(*p1 !=  '\0' )p1++;
    while(*p2 !=  '\0'  ){
        *p1 =*p2;p1++ ;p2++;
    }
    cout<<"Resultant String = "<<str1<<endl;}
