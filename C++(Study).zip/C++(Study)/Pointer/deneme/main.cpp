//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/23/23.
//

#include "iostream"

using namespace std;

int fonksiyon(int x_){
    // 2000 satirli kod
    x_ = 34;
    return x_;
}
void fonksyion1(int *p){
    // 2000 satirli kod
    *p = 38;
}
int main(){
    
    int x = 7;
    int *ptr = &x; // adress of x
    cout << x << endl;
    cout << *ptr << endl;
    cout << *&x << endl;
    cout << ptr << endl; // ramdeki adres
    cout << &x << endl; // ramdeki adres
    
    *ptr = 8 ;
    cout << x << endl;
    cout << *ptr << endl;
    cout << *&x << endl;
    cout << ptr << endl; // ramdeki adres
    cout << &x << endl; // ramdeki adres
    
    x = fonksiyon(x);
    cout << x << endl;
    cout << *ptr << endl;
    cout << *&x << endl;
    cout << ptr << endl; // ramdeki adres
    cout << &x << endl; // ramdeki adres
    
    fonksyion1(ptr);
    cout << x << endl;
    cout << *ptr << endl;
    cout << *&x << endl;
    cout << ptr << endl; // ramdeki adres
    cout << &x << endl; // ramdeki adres
}
