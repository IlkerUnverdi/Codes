//
//  main.cpp
//  Ders Denemeleri
//
//  Created by İlker Ünverdi on 10/12/23.
//

#include <iostream>

using namespace std;
int main(){
    long double a, b, d;
    string c;
    cout << "Please enter the first number that you want to calculate" << endl;
    cin >> a;
    cout <<"Please enter the second number that you want to calculate" << endl;
    cin >> b;
    while (true)
    {
        cout << "Which transaction do you want to do?" << endl;
        cin >> c;
        if (c == "+")
        {
            d = a + b;
            break;
        }
        else if (c == "-")
        {
            d = a - b;
            break;
        }
        else if (c == "*")
        {
            d = a * b;
            break;
        }
        else if (c == "/")
        {
            d = a / b;
            break;
        }
        else
        {
            cout << "Error, please re-enter again!" << endl;
        }
    }
    cout << "The result is: " << a << c << b << " = " << d << endl;
    return 0;
}
