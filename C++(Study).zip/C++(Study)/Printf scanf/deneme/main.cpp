//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/17/23.
//

#include <iostream>

using namespace std;
int main(){
    int x = 5;
    float y = 3.22;
    // cout << "Sayilar: x: " << x << " ve y: " << y << endl;
    printf("Sayilar: x: %d ve y: %.1f", x, y);
    // C den geliyor c++ a, float sayisi icin 6 tane sifir koyuyor %.1f yazarsan sifirdan sonra 1 rakam koyar.
    char metin[] = "Merhaba";
    printf("Metin: %s", metin);
    
    scanf("%d", &x);
    printf ("%d", x); 
}
