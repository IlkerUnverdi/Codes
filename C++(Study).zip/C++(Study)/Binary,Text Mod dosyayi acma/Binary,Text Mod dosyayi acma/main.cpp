//
//  main.cpp
//  Binary,Text Mod dosyayi acma
//
//  Created by İlker Ünverdi on 11/21/23.
//

#include <iostream>
#include <fstream>

using namespace std;

int main(){
    fstream file;
    file.open("/Users/ilkerunverdi/Desktop/Deneme/Dosyaadi.txt", ios::in);
    if(!file.is_open()){
        cout << "Dosya Acilamiyor";
    }
    else
    {
        string str;
        while (getline(file, str)) {
            cout << str << endl;
        }
        file.close();
    }
    return 0;
}

