//
//  main.cpp
//  array pointer
//
//  Created by İlker Ünverdi on 10/24/23.
//

#include <iostream>

using namespace std;

int main(){
    
    int arr[] = {34, 47, 85};
    int *p;
    p = arr;
    cout << p[1];
}
