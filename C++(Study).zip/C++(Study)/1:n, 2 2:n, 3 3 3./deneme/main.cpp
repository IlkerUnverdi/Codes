//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/20/23.
//

#include <iostream>

using namespace std;
int main(){
    // Kullanicidan sayi almak
    int girilensayi;
    cout << "Lutfen bir sayi giriniz: ";
    cin >> girilensayi;
    //Sayiyi
    //1
    //2 2
    //3 3 3 seklinde yazdirmak
    for (int y = 1; y <= girilensayi; y++){
        for (int x = 0; x < y; x++) {
            cout << y << " ";
        }
        cout << endl;
    }
}
