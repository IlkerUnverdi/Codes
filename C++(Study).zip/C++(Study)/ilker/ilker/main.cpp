#include <iostream>
using namespace std;
int main(){

    char c = 'b';
    int a = 98;
    cout<<int(c)<<endl;
    cout<<"a = "<<endl;
    cout<<"b"<<endl;
    cout<<a<<endl;
    cout<<1768/234<<endl;

    return 0;
}
