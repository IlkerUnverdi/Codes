#include "MyClass.hpp"

MyClass::MyClass()
    :public_number(-1), private_number(-1), name("No name")
{
}

MyClass::MyClass(int num1, string n) {
    public_number = num1;
    setPrivate_number(-1);
    name = n;
}

MyClass::MyClass(int num1, int num2, string n) {
    public_number = num1;
    if (num2 >= 0) {
        private_number = -1;
        cerr << "Wrong input" << endl;
    }
    else {
        private_number = num2;
    }
    name = n;
}

MyClass::MyClass(const MyClass& obj)
    :private_number(obj.private_number), name(obj.name)
{
    public_number = obj.public_number;

}

MyClass::~MyClass()
{
    cout << name << " is destroyed" << endl;
}

int MyClass::getPrivate_number() {
    return private_number;
}
