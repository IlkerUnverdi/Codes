//
//  MyClass.hpp
//  deneme
//
//  Created by İlker Ünverdi on 3/22/24.
//

#ifndef MyClass_hpp
#define MyClass_hpp

#include <stdio.h>
#include <iostream>
#include <string>

using namespace std;

class MyClass
{
public:

    MyClass();
    MyClass(int, string);
    MyClass(int num1, int num2, string n);

    MyClass(const MyClass& obj);

    ~MyClass();

    MyClass& operator=(MyClass& obj) = default;
    
    void setPrivate_number(int num) {
        private_number = num;
    }
    int getPrivate_number();

    int public_number;
    string name;

private:
    int private_number;
};

#endif /* MyClass_hpp */
