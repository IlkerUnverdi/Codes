#include <iostream>
#include "MyClass.hpp"

using namespace std;

int main()
{
    cout << "Hello World!\n";
    MyClass mc;
    //mc.public_number = 5;
    cout << mc.public_number << endl;
    //mc.setPrivate_number(10);
    cout << mc.getPrivate_number() << endl;
    cout << mc.name << endl;
    cout << "------------------------" << endl;
    MyClass mc1(2,"obj1");
    cout << mc1.public_number << endl;
    cout << mc1.getPrivate_number() << endl;
    cout << mc1.name << endl;
    cout << "------------------------" << endl;
    MyClass mc2(2,3,"obj2");
    cout << mc2.public_number << endl;
    cout << mc2.getPrivate_number() << endl;
    cout << mc2.name << endl;
    cout << "------------------------" << endl;
    MyClass mc3(2, -5,"obj3");
    cout << mc3.public_number << endl;
    cout << mc3.getPrivate_number() << endl;
    cout << mc3.name << endl;
    cout << "------------------------" << endl;
    MyClass mc4(mc);
    cout << mc4.public_number << endl;
    cout << mc4.getPrivate_number() << endl;
    cout << mc4.name << endl;
    mc4.name = "obj4";
    cout << "------------------------" << endl;
    MyClass mc5(9, -2, "obj5");
    cout << mc5.public_number << endl;
    cout << mc5.getPrivate_number() << endl;
    cout << mc5.name << endl;
    mc5 = mc;
    cout << mc5.public_number << endl;
    cout << mc5.getPrivate_number() << endl;
    cout << mc5.name << endl;
    cout << "------------------------" << endl;
}
