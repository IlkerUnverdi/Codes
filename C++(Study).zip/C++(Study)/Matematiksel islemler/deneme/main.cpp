//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/16/23.
//

#include <iostream>
#include <cmath> // cmath i windows ve iosta iostreame dahil linuxda yok.
using namespace std;
int main(){
    long y, z, a, b;
    int x;
    y = pow(2,31);
    x = pow(2,31);
    z = floor(2.9); // kendinden kucuk en buyuk tam sayi
    a = ceil(2.1); // kendin buyuk en kucuk tam sayi
    b = round (2.5); // Klasik yuvarlama
    cout << y << endl <<  x << endl;
    cout << z << endl;
    cout << a << endl;
    cout << b << endl;
    return 0;
}
