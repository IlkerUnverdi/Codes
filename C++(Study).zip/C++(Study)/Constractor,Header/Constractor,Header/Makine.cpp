//
//  Makine.cpp
//  Constractor,Header
//
//  Created by İlker Ünverdi on 11/14/23.
//

#include "Makine.hpp"

Makine::Makine(string _renk, string _model, int _uretimsuresi){
    renk =_renk;
    model = _model;
    uretimsuresi = _uretimsuresi;
}

void Makine::makinetipi(){
    cout << renk << endl;
    cout << model << endl;
    cout << uretimsuresi << endl;
}

void Makine::setMakinerenk(string _renk){
    renk = _renk;
}
string Makine::getMakinerenk(){
    return renk;
}
