//
//  Makine.hpp
//  Constractor,Header
//
//  Created by İlker Ünverdi on 11/14/23.
//

#ifndef Makine_hpp
#define Makine_hpp

#include <stdio.h>
#include <iostream>

#endif /* Makine_hpp */

using namespace std;

class Makine {
private:
    string renk;
    string model;
    int uretimsuresi;
public:
    void makinetipi();
    Makine(string _renk, string _model, int _uretimsuresi);
    void setMakinerenk(string _renk);
    string getMakinerenk();
};
