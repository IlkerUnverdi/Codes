//
//  main.cpp
//  Constractor,Header
//
//  Created by İlker Ünverdi on 11/14/23.
//

#include <iostream>
#include "Makine.hpp"

using namespace std;

int main(){
    Makine makine1("beyaz", "a", 15);
    makine1.setMakinerenk("Kirmizi");
    makine1.makinetipi();
    cout << makine1.getMakinerenk() << endl;
    Makine *p;
    p = new Makine("siyah", "b", 20);
    p-> setMakinerenk("beyaz");
    p -> makinetipi();
    cout << p-> getMakinerenk() << endl;
    delete p;
    p-> makinetipi();
}
