//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/20/23.
//

#include <iostream>
using namespace std;
int main(){
    int a = 2;
    int b = 3;
    int dizi[2][3] = { {21, 34, 43},
                       {22, 35, 47} };
    for (int y = 0; y < a; y++) {
        for (int i = 0; i < b; i++) {
            cout << dizi[y][i] << " ";
        }
        cout << endl;
    }
}
