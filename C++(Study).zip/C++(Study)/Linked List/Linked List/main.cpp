//
//  main.cpp
//  Linked List
//
//  Created by İlker Ünverdi on 12/10/23.
//

#include <iostream>
#include "node.hpp"
#include "LinkedList.hpp"

using namespace std;

int main(){
    LinkedList *linkedlist1 = new LinkedList(12);
    linkedlist1->appendList(7);
    linkedlist1->appendList(13);
    linkedlist1->appendList(24);
    linkedlist1->appendList(53);
    linkedlist1->appendList(1);
    linkedlist1->appendList(79);
    
    linkedlist1->deletelastnode();
    linkedlist1->deletelastnode();
    
    linkedlist1->printHead();
    linkedlist1->printTail();
    linkedlist1->getCount();
    linkedlist1->printList();
    
    
    delete linkedlist1;
}
