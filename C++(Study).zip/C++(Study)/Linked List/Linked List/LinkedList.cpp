//
//  LinkedList.cpp
//  Linked List
//
//  Created by İlker Ünverdi on 12/10/23.
//

#include "LinkedList.hpp"

LinkedList::LinkedList(int _deger) : node(_deger){
    deger = _deger;
    node *Node = new node(deger);
    head = Node;
    tail = Node;
    count = 1;
}

LinkedList::~LinkedList(){
    cout << "Destructor cagirildi" << endl;
    node *tmp = head;
    while (head){
        head = head->next;
        delete tmp;
        tmp = head;
    }
}

void LinkedList::printHead(){
    if (head != NULL) {
        cout << "Head: " << head->deger << endl;
    }
}

void LinkedList::printTail(){
    if (tail != NULL)
        cout << "Tail: " << tail->deger << endl;
}

void LinkedList::getCount(){
    cout << "List Count: " << this->count << endl;
}

void LinkedList::appendList(int _deger){
    deger = _deger;
    node *Node = new node(deger);
    
    if (count == 0) {
        head = Node;
        tail = Node;
    }
    else{
        tail->next = Node;
        tail = Node;
        count ++;
    }
}

void LinkedList::printList(){
    node *tmp = head;
    while (tmp != NULL) {
        cout << tmp->deger << ", ";
        tmp = tmp->next;
    }
    cout << endl;
}

void LinkedList::deletelastnode(){
    node *tmp1 = head;
    node *tmp2 = head;
    
    while (tmp1->next) {
        tmp2 = tmp1;
        tmp1 = tmp1->next;
    }
    tail = tmp2;
    tail->next = NULL;
    count--;
    delete tmp1;
}
