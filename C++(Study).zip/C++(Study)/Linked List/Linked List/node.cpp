//
//  linkedlist.cpp
//  Linked List
//
//  Created by İlker Ünverdi on 12/10/23.
//

#include "node.hpp"

node::node(int _deger){
    this->deger = _deger;
    next = NULL;
}
