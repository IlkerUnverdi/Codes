//
//  linkedlist.hpp
//  Linked List
//
//  Created by İlker Ünverdi on 12/10/23.
//

#ifndef linkedlist_hpp
#define linkedlist_hpp

#include <stdio.h>
#include <iostream>

using namespace std;

class node {
public:
    int deger;
    node *next;
    node(int _deger);
};

#endif /* linkedlist_hpp */
