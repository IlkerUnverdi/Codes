//
//  LinkedList.hpp
//  Linked List
//
//  Created by İlker Ünverdi on 12/10/23.
//

#ifndef LinkedList_hpp
#define LinkedList_hpp

#include <stdio.h>
#include "node.hpp"

class LinkedList : public node{
private:
    node *head;
    node *tail;
    int count;
    
public:
    LinkedList(int _deger);
    ~LinkedList();
    void printHead();
    void printTail();
    void getCount();
    void appendList(int _deger);
    void printList();
    void deletelastnode();
    void addfirstnode();
};

#endif /* LinkedList_hpp */
