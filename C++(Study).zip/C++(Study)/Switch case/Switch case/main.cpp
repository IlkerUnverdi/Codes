//
//  main.cpp
//  Switch case
//
//  Created by İlker Ünverdi on 10/20/23.
//

#include <iostream>

using namespace std;

int main(){
    int sayi;
    cout << "1 ile 3 arasinda bir sayi giriniz: ";
    cin >> sayi;
    switch (sayi) {
        case 1:
            cout << "Bir" << endl;
            break;
        case 2:
            cout << "Iki" << endl;
            break;
        case 3:
            cout << "Uc" << endl;
            break;
            
        default:
            cout << "1 Ile 3 arasinda bir rakam girmediniz." << endl;
            break;
    }
}
