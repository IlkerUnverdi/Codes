//
//  Father.hpp
//  deneme
//
//  Created by İlker Ünverdi on 3/29/24.
//

#ifndef Father_hpp
#define Father_hpp

#include <stdio.h>
#include "Parents.hpp"

class Father : public Parents {
public:
    
    void setsurname(string _surname);
    string getsurname();
    
    Father(string _name, string _surname, int _age, int _income);
    void showfatherinformation();
};

#endif /* Father_hpp */
