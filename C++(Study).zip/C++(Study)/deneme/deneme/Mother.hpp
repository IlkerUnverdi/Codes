//
//  Mother.hpp
//  deneme
//
//  Created by İlker Ünverdi on 3/29/24.
//

#ifndef Mother_hpp
#define Mother_hpp

#include <stdio.h>
#include "Parents.hpp"

class Mother : public Parents {
public:
    
    void setsurname(string _surname);
    string getsurname();
    
    Mother(string _name, string _surname, int _age, int _income);
    void showmotherinformation();
};

#endif /* Mother_hpp */
