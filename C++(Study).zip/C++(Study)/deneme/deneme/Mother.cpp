//
//  Mother.cpp
//  deneme
//
//  Created by İlker Ünverdi on 3/29/24.
//

#include "Mother.hpp"

Mother::Mother(string _name, string _surname, int _age, int _income) : Parents(_name, _surname, _age, _income){
    
}

void Mother::showmotherinformation(){
    cout << "Name of mother: " << Parents::name << " " << Parents::surname << endl;
    cout << "Age: " << Parents::age << endl;
    cout << "Her income: " << Parents::income << endl;
}
