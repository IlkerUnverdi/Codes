#include <iostream>
#include <list>
#include "Father.hpp"
#include "Mother.hpp"

using namespace std;

void showmenu(){
    cout << "Please choose one of the options" << endl;
    cout << "1-Add Family" << endl;
    cout << "2-Show family informations" << endl;
    cout << "3-Delete Family" << endl;
    cout << "4-Exit" << endl;
}
void addfamily(list<Father> *list1, list<Mother> *list2){
    string name, surname, Family;
    int age, income;
    cout << "Please enter name of father and his surname with a space between them: ";
    cin >> name >> surname;
    cout << "Please enter his age: ";
    cin >> age;
    cout << "Please enter his income: ";
    cin >> income;
    Father father1(name, surname, age, income);
    list1->push_back(father1);
    father1.showfatherinformation();
    cout << name << " "  << surname << " has added successfully" << endl;
    cout << "Please enter name of mother and her surname with a space between them: ";
    cin >> name >> surname;
    cout << "Please enter her age: ";
    cin >> age;
    cout << "Please enter her income: ";
    cin >> income;
    Mother mother1(name, surname, age, income);
    list2->push_back(mother1);
    mother1.showmotherinformation();
    cout << name << " "  << surname << " has added successfully" << endl;
}

void showfamilyinformation(list<Father> *list1, list<Mother> *list2){
    int number = 1;
    cout << "List of Families" << endl;
    list<Father>::iterator it1;
    list<Mother>::iterator it2;
    for (it1 = list1->begin(), it2 = list2->begin(); it1 != list1->end(), it2 != list2->end(); it1++, it2++) {
        cout << "Family number " << number << endl;
        it1->showfatherinformation();
        it2->showmotherinformation();
        cout << endl;
        number++;
    }
}

void erasefamily(list<Father> *list1, list<Mother> *list2){
    string surname;
    cout << "Please enter the family surname you want to erase: ";
    cin >> surname;
    list<Father>::iterator it1;
    list<Mother>::iterator it2;
    for (it1 = list1->begin(), it2 = list2->begin(); it1 != list1->end(), it2 != list2->end(); it1++, it2++) {
        if (it1->getsurname() == surname){
            list1->erase(it1);
            list2->erase(it2);
            cout << "Family has erased successufly" << endl;
            return;
        }
    }
}

int main(){
    list<Father> *Fatherlist = new list<Father>();
    list<Mother> *Motherlist = new list<Mother>();
    int x;
    do{
        showmenu();
        cin >> x;
        if (x == 1){
            addfamily(Fatherlist, Motherlist);
        }
        else if (x == 2){
            showfamilyinformation(Fatherlist, Motherlist);
        }
        else if (x == 3){
            erasefamily(Fatherlist, Motherlist);
        }
        
        
    }while (x != 4);
    cout << "You exited successfully" << endl;
    
    
    return 0;
}


