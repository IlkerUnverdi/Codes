//
//  Parents.hpp
//  deneme
//
//  Created by İlker Ünverdi on 3/29/24.
//

#ifndef Parents_hpp
#define Parents_hpp

#include <iostream>
#include <stdio.h>

using namespace std;

class Parents {
    
public:
    string name;
    string surname;
    int age;
    int income;
    
    Parents(string _name, string _surname, int _age, int _income);
    
};

#endif /* Parents_hpp */
