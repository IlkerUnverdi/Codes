//
//  MyClass.cpp
//  deneme
//
//  Created by İlker Ünverdi on 3/22/24.
//

#include "MyClass.hpp"

MyClass::MyClass() {
    public_data = -1;
    private_data = -1;
}

MyClass::MyClass(int num1)
{
    public_data = num1;
    setPrivate_data(num1);
}

MyClass::MyClass(int num1, int num2)
{
    public_data = num1;
    if (num2 >= 0) {
        cout << "Wrong input" << endl;
        private_data = -1;
    }
    else {
        private_data = num2;
    }
}

int MyClass::getPrivate_data()
{
    return private_data;
}
