//
//  Father.cpp
//  deneme
//
//  Created by İlker Ünverdi on 3/29/24.
//

#include "Father.hpp"

Father::Father(string _name, string _surname, int _age, int _income) : Parents(_name, _surname, _age, _income){
    
}

void Father::showfatherinformation(){
    cout << "Name of father: " << Parents::name << " " << Parents::surname << endl;
    cout << "Age: " << Parents::age << endl;
    cout << "His income: " << Parents::income << endl;
}

void Father::setsurname(string _surname){
    surname = _surname;
}
string Father::getsurname(){
    return surname;
}
