//
//  Parents.cpp
//  deneme
//
//  Created by İlker Ünverdi on 3/29/24.
//

#include "Parents.hpp"

Parents::Parents(string _name, string _surname, int _age, int _income){
    name = _name;
    surname = _surname;
    age = _age;
    income = _income;
}
