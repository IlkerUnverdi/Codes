//
//  main.cpp
//  for exercise
//
//  Created by İlker Ünverdi on 10/31/23.
//

#include <iostream>
#include <chrono>

using namespace std;
int main(){
    int sayi;
    cout << "Lutfen sayi girin: ";
    cin >> sayi;
    chrono::steady_clock::time_point begin = std:: chrono::steady_clock::now();
    for (int output = 1; output <= sayi; output++) {
        if (output %2 != 0) {
            for (int input = 0; input <= sayi-output; input++) {
                cout << " ";
            }
            for (int yildiz = 1; yildiz <= output; yildiz++) {
                for (int c = output; c <= output; c++) {
                    cout <<" " << "*";
                }
            }
            cout << endl;
        }
    }
    chrono::steady_clock::time_point end= std:: chrono::steady_clock::now();
    cout << "Time difference: " << chrono::duration_cast<chrono::seconds>(end - begin).count() << endl;
   }
