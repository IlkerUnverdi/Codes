//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/17/23.
//

#include <iostream>

using namespace std;
int main(){
    int number, x, a;
    cout << "Enter a number" << endl;
    cin >> number;
    x = 1;
    a = 0;
    while (x <= number) {
        if (x % 7 == 0) {
            cout << x << endl;
        }
        x++;
    }
}
