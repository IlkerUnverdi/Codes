//
//  main.cpp
//  Hello, World!
//
//  Created by İlker Ünverdi on 10/8/23.
//
// The first code
//
//
// her zaman bir kutuphane eklemen lazim iostream ekliyoruz
#include <iostream>

using namespace std;
int main() {
    cout <<"Hello, World!" << endl;
    return 0;
}
