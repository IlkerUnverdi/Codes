//
//  main.cpp
//  Binary,Text Mod
//
//  Created by İlker Ünverdi on 11/21/23.
//

#include <iostream>
#include <fstream>

using namespace std;

int main(){
    fstream file;
    file.open("/Users/ilkerunverdi/Desktop/Deneme/Dosyaadi.txt", ios::out | ios::binary | ios :: app);
    if(!file.is_open()){
        cout << "Dosya Acilamiyor";
    }
    else
    {
        string str = "Hello World!";
        file << str;
        file.close();
    }
    return 0;
}
