//
//  main.cpp
//  deneme
//
//  Created by İlker Ünverdi on 10/17/23.
//

#include <iostream>

using namespace std;
int main() {
    int until = 0;
    long x;
    x = pow(2, 20);
    while(until <= x){
        cout << until << endl;
        until = until +1;
    }
    return 0;
}
